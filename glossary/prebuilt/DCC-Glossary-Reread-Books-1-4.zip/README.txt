DUNGEON CRAWLER CARL GLOSSARY - SPOILER-GATED EDITION
for the sn-dictionary Supernote plugin

HOW IT WORKS
There is one dictionary per book: "DCC thru Book N". Each one contains only
what has been revealed by the end of Book N. That covers facts, relationships,
and even names: a character or alias that first appears in a later book is
not in it at all. Every line is tagged [1]-[8] with the book that reveals it.

The dictionaries are cumulative, so you only ever need ONE enabled.

INSTALL (right now, while reading Book 6)
1. Remove the old full-spoiler dictionary first. In the lookup popup, tap the
   gear icon, find "Dungeon Crawler Carl", and tap Remove. That deletes its
   database and source files. Just deleting the files from MyStyle/SnDict
   is not enough: the plugin keeps its own imported copy.
2. Copy the folder DCC-Book-5 into MyStyle/SnDict/
3. Reopen the plugin. It imports new folders on launch.

MOVING ON / REREADING
- When you finish a book, copy the next folder in, reopen the plugin, then in
  Settings untick or Remove the previous "DCC thru Book N".
- Don't leave several layers enabled at once. The plugin searches every
  enabled dictionary and shows each as its own section, so the highest layer
  would show its spoilers.
- For a reread, start from DCC-Book-1 and step up.

ZIPS
  DCC-Glossary-INSTALL-NOW.zip        DCC-Book-5 only
  DCC-Glossary-Reread-Books-1-4.zip   earlier layers (safe)
  DCC-Glossary-SPOILERS-Books-6-8.zip later layers. Don't open until you get there.

Compiled from the novels by Matt Dinniman. Unofficial fan reference.
